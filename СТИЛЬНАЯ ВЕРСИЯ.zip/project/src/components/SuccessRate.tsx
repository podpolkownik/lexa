import React, { useEffect, useState, useRef } from 'react';
import { TrendingUp, Award, Target, Zap, BarChart3, Trophy } from 'lucide-react';

const SuccessRate = () => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [activeMetric, setActiveMetric] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  const metrics = [
    { value: 85, label: "Success Rate", suffix: "%", icon: Target, color: "from-green-500 to-emerald-600" },
    { value: 127, label: "Avg. Daily Profit", suffix: "$", icon: TrendingUp, color: "from-blue-500 to-cyan-600" },
    { value: 94, label: "Member Satisfaction", suffix: "%", icon: Award, color: "from-purple-500 to-pink-600" },
    { value: 15, label: "Months Track Record", suffix: "+", icon: Trophy, color: "from-yellow-500 to-orange-600" }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          
          // Animate counter to 85
          let start = 0;
          const duration = 2500;
          const increment = 85 / (duration / 16);
          
          const timer = setInterval(() => {
            start += increment;
            if (start >= 85) {
              setCount(85);
              clearInterval(timer);
            } else {
              setCount(Math.floor(start));
            }
          }, 16);

          return () => clearInterval(timer);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Cycle through metrics
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveMetric((prev) => (prev + 1) % metrics.length);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-green-100/50 to-blue-100/50 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-purple-100/50 to-pink-100/50 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className={`text-center transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          {/* Enhanced Header */}
          <div className="mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-green-100 to-blue-100 px-6 py-3 rounded-full mb-6 border border-green-200">
              <Award className="w-6 h-6 text-green-600" />
              <span className="text-green-800 font-bold text-lg">Proven Track Record</span>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
              Our AI Delivers{' '}
              <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                Exceptional Results
              </span>
            </h2>
            
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Advanced machine learning algorithms analyze thousands of data points to deliver 
              the most accurate sports betting predictions in the industry.
            </p>
          </div>

          {/* Main Success Rate Display */}
          <div className="relative mb-16">
            <div className="flex justify-center">
              <div className="relative group">
                {/* Main circle */}
                <div className="w-64 h-64 bg-gradient-to-br from-green-500 via-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl transform group-hover:scale-105 transition-all duration-500 relative overflow-hidden">
                  <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-5xl md:text-6xl font-black text-gray-900 mb-2">
                        {count}%
                      </div>
                      <div className="text-lg font-bold text-gray-600">Success Rate</div>
                    </div>
                  </div>
                  
                  {/* Animated border */}
                  <div className="absolute inset-0 rounded-full border-4 border-white/30 animate-spin-slow" />
                </div>
                
                {/* Floating icons */}
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg animate-bounce">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                
                <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg animate-bounce" style={{ animationDelay: '0.5s' }}>
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                
                {/* Pulse rings */}
                <div className="absolute inset-0 w-64 h-64 bg-gradient-to-br from-green-500 via-blue-500 to-purple-600 rounded-full animate-ping opacity-20" />
                <div className="absolute inset-0 w-64 h-64 bg-gradient-to-br from-green-500 via-blue-500 to-purple-600 rounded-full animate-ping opacity-10" style={{ animationDelay: '1s' }} />
              </div>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {metrics.map((metric, index) => {
              const IconComponent = metric.icon;
              const isActive = index === activeMetric;
              
              return (
                <div 
                  key={index}
                  className={`bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-gray-100 transition-all duration-500 transform ${
                    isActive ? 'scale-110 shadow-2xl ring-2 ring-blue-200' : 'hover:scale-105 hover:shadow-xl'
                  }`}
                >
                  <div className={`w-12 h-12 bg-gradient-to-r ${metric.color} rounded-xl flex items-center justify-center mx-auto mb-4 ${isActive ? 'animate-bounce' : ''}`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className={`text-2xl md:text-3xl font-black text-gray-900 mb-2 ${isActive ? 'animate-pulse' : ''}`}>
                    {metric.suffix === "$" ? metric.suffix : ""}{metric.value}{metric.suffix !== "$" ? metric.suffix : ""}
                  </div>
                  <div className="text-sm text-gray-600 font-semibold">{metric.label}</div>
                </div>
              );
            })}
          </div>

          {/* Feature highlights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-8 rounded-2xl border border-green-200 hover:shadow-lg transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Consistent Winners</h3>
              <p className="text-gray-600 leading-relaxed">
                Our advanced AI analyzes over 10,000 data points per match across tennis, football, and basketball 
                to identify the most profitable betting opportunities with mathematical precision.
              </p>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-8 rounded-2xl border border-blue-200 hover:shadow-lg transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Verified Results</h3>
              <p className="text-gray-600 leading-relaxed">
                Every signal is tracked, verified, and documented. Our 85% success rate is based on real results 
                from our active community of 10,000+ profitable bettors worldwide.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessRate;