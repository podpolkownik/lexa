import React from 'react';
import { MessageCircle, Instagram, Shield, Zap } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">BetSignal</span>
            </div>
            <p className="text-gray-400 mb-4">
              Premium AI-powered sports betting signals with 85% success rate. Join 10,000+ profitable bettors worldwide.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center hover:bg-green-700 transition-colors">
                <MessageCircle className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-pink-600 rounded-lg flex items-center justify-center hover:bg-pink-700 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">How It Works</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Success Stories</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Free Trial</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact Support</a></li>
            </ul>
          </div>

          {/* Contact & Support */}
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2 text-gray-400">
              <li>📱 WhatsApp: +1-XXX-XXX-XXXX</li>
              <li>💬 Telegram: @BetSignalSupport</li>
              <li>📧 Email: support@betsignal.com</li>
              <li>🕒 24/7 Customer Support</li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer Ticker */}
        <div className="border-t border-gray-800 pt-8">
          <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-2">
              <Shield className="w-5 h-5 text-yellow-500 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-200">
                <strong>Legal Disclaimer:</strong> Sports betting involves risk. Past performance does not guarantee future results. 
                Our 85% success rate is based on historical data and may not reflect future performance. 
                Please bet responsibly and within your means. Only bet what you can afford to lose. 
                Must be 18+ to participate. Gambling laws vary by jurisdiction - ensure compliance with local regulations.
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
            <div>
              © 2024 BetSignal. All rights reserved. 
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Responsible Gambling</a>
            </div>
          </div>

          {/* Sports ticker effect */}
          <div className="mt-6 overflow-hidden bg-gray-800 rounded-lg">
            <div className="animate-pulse px-4 py-2 text-center text-xs text-gray-500">
              🏆 Live Updates: Tennis • Football • Basketball • AI Analysis • Real-time Signals • 24/7 Support 🏆
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;