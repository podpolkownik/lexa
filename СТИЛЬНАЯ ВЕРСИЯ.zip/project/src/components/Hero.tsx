import React, { useEffect, useState } from 'react';
import { Trophy, Target, Zap, Star, TrendingUp, Users, Award } from 'lucide-react';

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentStat, setCurrentStat] = useState(0);

  const stats = [
    { icon: Target, value: "85%", label: "AI Precision", color: "text-green-500" },
    { icon: Users, value: "10K+", label: "Winners", color: "text-blue-500" },
    { icon: Award, value: "5-10", label: "Daily Signals", color: "text-purple-500" },
    { icon: TrendingUp, value: "$1.2M+", label: "Total Profits", color: "text-yellow-500" }
  ];

  useEffect(() => {
    setIsVisible(true);
    
    // Rotate stats every 3 seconds
    const interval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % stats.length);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative bg-gradient-to-br from-white via-green-50/30 to-blue-50/30 py-16 md:py-24 overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-green-200/20 to-blue-200/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-purple-200/20 to-pink-200/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        
        {/* Floating elements */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-gradient-to-r from-green-400 to-blue-500 rounded-full opacity-30 animate-float"
            style={{
              left: `${10 + Math.random() * 80}%`,
              top: `${10 + Math.random() * 80}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className={`text-center transition-all duration-1500 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
        }`}>
          {/* Enhanced Hero Icon */}
          <div className="flex justify-center mb-8">
            <div className="relative group">
              <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-2xl flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-all duration-300 animate-bounce">
                <Trophy className="w-12 h-12 text-white" />
              </div>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg animate-pulse">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div className="absolute inset-0 w-24 h-24 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-2xl animate-ping opacity-20" />
            </div>
          </div>

          {/* Enhanced Headlines */}
          <div className="space-y-6 mb-12">
            <h1 className="text-4xl md:text-7xl font-black text-gray-900 leading-tight">
              Win with{' '}
              <span className="bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent animate-gradient">
                85% AI Precision!
              </span>{' '}
              <span className="inline-block animate-bounce">🏆</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed font-medium">
              Join <span className="font-bold text-green-600">10,000+ elite bettors</span> using our revolutionary AI to transform sports knowledge into{' '}
              <span className="font-bold text-blue-600">consistent daily profits</span>. 
              Expert picks with <span className="font-bold text-purple-600">proven results!</span> 💰
            </p>
          </div>

          {/* Dynamic Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mb-12">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon;
              const isActive = index === currentStat;
              
              return (
                <div 
                  key={index}
                  className={`bg-white/80 backdrop-blur-sm p-6 md:p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 transform ${
                    isActive ? 'scale-110 shadow-2xl ring-2 ring-blue-200' : 'hover:scale-105'
                  }`}
                >
                  <IconComponent className={`w-8 h-8 md:w-10 md:h-10 ${stat.color} mx-auto mb-3 ${isActive ? 'animate-bounce' : ''}`} />
                  <div className={`text-2xl md:text-3xl font-black text-gray-900 mb-1 ${isActive ? 'animate-pulse' : ''}`}>
                    {stat.value}
                  </div>
                  <div className="text-sm md:text-base text-gray-600 font-semibold">{stat.label}</div>
                </div>
              );
            })}
          </div>

          {/* Enhanced CTA Section */}
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
              <button className="group bg-gradient-to-r from-green-500 via-blue-500 to-purple-600 text-white px-8 md:px-12 py-4 md:py-5 rounded-2xl text-lg md:text-xl font-black hover:from-green-600 hover:via-blue-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-3xl w-full md:w-auto relative overflow-hidden">
                <span className="relative z-10 flex items-center justify-center gap-3">
                  Join for $99/month! 
                  <Star className="w-6 h-6 group-hover:rotate-180 transition-transform duration-300" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </button>
              
              <div className="text-center md:text-left">
                <p className="text-lg font-bold text-gray-700">Or try 3 days FREE!</p>
                <p className="text-sm text-gray-500">No commitment • Cancel anytime</p>
              </div>
            </div>
            
            {/* Trust indicators */}
            <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                <span className="font-semibold">Live AI Analysis</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
                <span className="font-semibold">24/7 Support</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse" />
                <span className="font-semibold">Instant Signals</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;