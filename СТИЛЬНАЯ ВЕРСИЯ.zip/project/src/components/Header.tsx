import React, { useEffect, useState } from 'react';
import { TrendingUp, Zap, Shield, Users } from 'lucide-react';

const Header = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-40 transition-all duration-300 ${
      isScrolled 
        ? 'bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-100' 
        : 'bg-white shadow-sm'
    }`}>
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className={`flex items-center justify-between transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          {/* Enhanced Logo */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 via-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform duration-200">
                <Zap className="w-7 h-7 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-white">AI</span>
              </div>
            </div>
            <div>
              <span className="text-2xl font-black text-gray-900 tracking-tight">BetSignal</span>
              <div className="text-xs text-gray-500 font-medium">Premium AI Sports Betting</div>
            </div>
          </div>
          
          {/* Enhanced Trust Indicators */}
          <div className="hidden md:flex items-center gap-6">
            <div className="flex items-center gap-2 bg-gradient-to-r from-green-50 to-emerald-50 px-4 py-2 rounded-full border border-green-200">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <span className="text-sm font-bold text-green-700">85% Win Rate</span>
            </div>
            
            <div className="flex items-center gap-2 bg-gradient-to-r from-blue-50 to-cyan-50 px-4 py-2 rounded-full border border-blue-200">
              <Users className="w-5 h-5 text-blue-600" />
              <span className="text-sm font-bold text-blue-700">10K+ Members</span>
            </div>
            
            <div className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-pink-50 px-4 py-2 rounded-full border border-purple-200">
              <Shield className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-bold text-purple-700">Verified Results</span>
            </div>
          </div>

          {/* Mobile trust indicator */}
          <div className="md:hidden">
            <div className="flex items-center gap-2 bg-gradient-to-r from-green-50 to-emerald-50 px-3 py-1 rounded-full border border-green-200">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-sm font-bold text-green-700">85% Success</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;