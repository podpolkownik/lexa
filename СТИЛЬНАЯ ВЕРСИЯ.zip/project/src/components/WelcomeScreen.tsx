import React, { useState, useEffect } from 'react';
import { Trophy, Zap, TrendingUp, ArrowRight, Star, Target } from 'lucide-react';

interface WelcomeScreenProps {
  onComplete: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [showSkip, setShowSkip] = useState(false);

  const steps = [
    {
      icon: Trophy,
      title: "Welcome to BetSignal",
      subtitle: "AI-Powered Sports Betting Revolution",
      description: "Join 10,000+ elite profitable bettors worldwide",
      gradient: "from-yellow-400 via-orange-500 to-red-500"
    },
    {
      icon: Target,
      title: "85% Success Rate",
      subtitle: "Proven AI Precision",
      description: "Our advanced algorithms deliver consistent winning signals",
      gradient: "from-green-400 via-blue-500 to-purple-600"
    },
    {
      icon: Star,
      title: "$1,250+ Daily Profits",
      subtitle: "Real Results, Real Money",
      description: "Members are earning substantial profits every single day",
      gradient: "from-emerald-400 via-teal-500 to-cyan-600"
    },
    {
      icon: Zap,
      title: "Ready to Transform?",
      subtitle: "Your Winning Journey Starts Now",
      description: "Turn your sports passion into consistent profit",
      gradient: "from-purple-400 via-pink-500 to-red-500"
    }
  ];

  useEffect(() => {
    // Show skip button after first step
    if (currentStep > 0) {
      setShowSkip(true);
    }

    const timer = setTimeout(() => {
      if (currentStep < steps.length - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        setTimeout(() => {
          setIsVisible(false);
          setTimeout(onComplete, 800);
        }, 3000);
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [currentStep, onComplete]);

  const handleSkip = () => {
    setIsVisible(false);
    setTimeout(onComplete, 500);
  };

  const currentStepData = steps[currentStep];
  const IconComponent = currentStepData.icon;

  return (
    <div className={`fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center transition-all duration-800 ${
      isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
    }`}>
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Floating orbs */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className={`absolute rounded-full bg-gradient-to-r ${currentStepData.gradient} opacity-10 animate-float`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${20 + Math.random() * 60}px`,
              height: `${20 + Math.random() * 60}px`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${4 + Math.random() * 4}s`
            }}
          />
        ))}
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%239C92AC%22 fill-opacity=%220.05%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%221%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30" />
      </div>

      <div className="text-center text-white px-6 max-w-lg mx-auto relative z-10">
        {/* Main icon with enhanced animation */}
        <div className="relative mb-12">
          <div className={`w-32 h-32 mx-auto bg-gradient-to-r ${currentStepData.gradient} rounded-full flex items-center justify-center shadow-2xl transform transition-all duration-1000 ${
            isVisible ? 'scale-100 rotate-0' : 'scale-0 rotate-180'
          }`}>
            <IconComponent className="w-16 h-16 text-white animate-pulse" />
          </div>
          
          {/* Pulsing rings */}
          <div className={`absolute inset-0 w-32 h-32 mx-auto bg-gradient-to-r ${currentStepData.gradient} rounded-full animate-ping opacity-20`} />
          <div className={`absolute inset-0 w-32 h-32 mx-auto bg-gradient-to-r ${currentStepData.gradient} rounded-full animate-ping opacity-10`} style={{ animationDelay: '0.5s' }} />
        </div>

        {/* Enhanced content with better typography */}
        <div className="space-y-6 animate-fade-in-up">
          <h1 className="text-4xl md:text-5xl font-black leading-tight bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            {currentStepData.title}
          </h1>
          
          <div className={`inline-block px-6 py-2 rounded-full bg-gradient-to-r ${currentStepData.gradient} bg-opacity-20 border border-white/20 backdrop-blur-sm`}>
            <p className="text-xl font-bold text-white">
              {currentStepData.subtitle}
            </p>
          </div>
          
          <p className="text-lg text-gray-300 leading-relaxed max-w-md mx-auto">
            {currentStepData.description}
          </p>
        </div>

        {/* Enhanced progress indicator */}
        <div className="flex justify-center gap-3 mt-12">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`relative transition-all duration-500 ${
                index <= currentStep ? 'scale-110' : 'scale-100'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full transition-all duration-500 ${
                  index <= currentStep 
                    ? `bg-gradient-to-r ${step.gradient} shadow-lg` 
                    : 'bg-white/20 border border-white/30'
                }`}
              />
              {index <= currentStep && (
                <div className={`absolute inset-0 w-4 h-4 rounded-full bg-gradient-to-r ${step.gradient} animate-ping opacity-30`} />
              )}
            </div>
          ))}
        </div>

        {/* Action buttons */}
        <div className="mt-12 space-y-4">
          {currentStep === steps.length - 1 && (
            <button
              onClick={handleSkip}
              className="group flex items-center gap-3 mx-auto bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 px-8 py-4 rounded-full text-white font-bold text-lg shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              Enter BetSignal
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>
          )}
          
          {showSkip && currentStep < steps.length - 1 && (
            <button
              onClick={handleSkip}
              className="text-white/60 hover:text-white text-sm font-medium transition-colors duration-200 underline decoration-dotted underline-offset-4"
            >
              Skip Introduction
            </button>
          )}
        </div>

        {/* Step counter */}
        <div className="absolute top-8 right-8 text-white/40 text-sm font-medium">
          {currentStep + 1} / {steps.length}
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;