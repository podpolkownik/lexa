import React, { useState, useEffect } from 'react';
import { Clock, Gift, Users, Check } from 'lucide-react';

const FreeTrialForm = () => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 45,
    seconds: 30
  });
  const [formData, setFormData] = useState({
    contactMethod: 'whatsapp',
    contact: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Countdown timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    // Here you would typically send the data to your backend
    console.log('Form submitted:', formData);
  };

  const contactOptions = [
    { value: 'whatsapp', label: 'WhatsApp', icon: '📱' },
    { value: 'telegram', label: 'Telegram', icon: '💬' },
    { value: 'email', label: 'Email', icon: '📧' },
    { value: 'instagram', label: 'Instagram', icon: '📸' }
  ];

  if (isSubmitted) {
    return (
      <section className="py-16 bg-gradient-to-br from-green-500 to-blue-500">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-2xl">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Welcome to BetSignal! 🎉</h3>
            <p className="text-gray-600 mb-6">
              Your 3-day free trial has been activated! You'll receive your first AI-powered betting signals within 24 hours.
            </p>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                Check your {formData.contactMethod} for further instructions and to join our exclusive Telegram channel.
              </p>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-gradient-to-br from-green-500 to-blue-500">
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-white rounded-2xl p-8 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 bg-yellow-100 px-4 py-2 rounded-full mb-4">
              <Gift className="w-5 h-5 text-yellow-600" />
              <span className="text-yellow-800 font-semibold">Limited Time Offer</span>
            </div>
            
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Get 3 Days <span className="text-green-600">FREE!</span> 🎁
            </h2>
            <p className="text-gray-600">
              Join thousands of profitable bettors and experience our 85% success rate
            </p>
          </div>

          {/* Countdown Timer */}
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-red-600" />
              <span className="text-red-800 font-semibold">Hurry, Limited Spots Remaining!</span>
            </div>
            <div className="flex justify-center gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{timeLeft.hours.toString().padStart(2, '0')}</div>
                <div className="text-xs text-red-500">Hours</div>
              </div>
              <div className="text-red-600 text-2xl font-bold">:</div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{timeLeft.minutes.toString().padStart(2, '0')}</div>
                <div className="text-xs text-red-500">Minutes</div>
              </div>
              <div className="text-red-600 text-2xl font-bold">:</div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{timeLeft.seconds.toString().padStart(2, '0')}</div>
                <div className="text-xs text-red-500">Seconds</div>
              </div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                How would you like to receive your signals?
              </label>
              <div className="grid grid-cols-2 gap-3">
                {contactOptions.map(option => (
                  <label key={option.value} className="cursor-pointer">
                    <input
                      type="radio"
                      name="contactMethod"
                      value={option.value}
                      checked={formData.contactMethod === option.value}
                      onChange={(e) => setFormData({...formData, contactMethod: e.target.value})}
                      className="sr-only"
                    />
                    <div className={`p-4 rounded-lg border-2 transition-all ${
                      formData.contactMethod === option.value
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}>
                      <div className="text-center">
                        <div className="text-2xl mb-1">{option.icon}</div>
                        <div className="text-sm font-semibold">{option.label}</div>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Your {contactOptions.find(opt => opt.value === formData.contactMethod)?.label} Contact
              </label>
              <input
                type={formData.contactMethod === 'email' ? 'email' : 'text'}
                value={formData.contact}
                onChange={(e) => setFormData({...formData, contact: e.target.value})}
                placeholder={
                  formData.contactMethod === 'email' ? 'your@email.com' :
                  formData.contactMethod === 'whatsapp' ? '+1234567890' :
                  formData.contactMethod === 'telegram' ? '@username' :
                  '@instagram_handle'
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white py-4 px-6 rounded-lg text-lg font-bold hover:from-green-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              Claim My FREE 3-Day Trial! 🚀
            </button>
          </form>

          {/* Trust indicators */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span>10,000+ members</span>
              </div>
              <div className="flex items-center gap-1">
                <Check className="w-4 h-4 text-green-600" />
                <span>No commitment</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FreeTrialForm;