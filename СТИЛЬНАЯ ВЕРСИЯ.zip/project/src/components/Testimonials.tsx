import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, User } from 'lucide-react';

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const testimonials = [
    {
      name: "Sarah T.",
      location: "Nigeria",
      profit: "$600",
      period: "1 week",
      text: "Earned $600 in a week! The signals are incredibly accurate and easy to follow. Best investment I've made this year! 🎾💰",
      rating: 5,
      sport: "Tennis"
    },
    {
      name: "Raj P.",
      location: "India",
      profit: "$890",
      period: "2 weeks",
      text: "Amazing results! The AI picks are spot on. Made $890 in just 2 weeks following their football signals. Highly recommend! ⚽",
      rating: 5,
      sport: "Football"
    },
    {
      name: "Mike Chen",
      location: "Malaysia",
      profit: "$1,200",
      period: "1 month",
      text: "Best betting service ever! Made $1,200 in my first month. The basketball predictions are unreal. Thank you BetSignal! 🏀🔥",
      rating: 5,
      sport: "Basketball"
    },
    {
      name: "Elena R.",
      location: "South Africa",
      profit: "$750",
      period: "10 days",
      text: "Skeptical at first, but the results speak for themselves. $750 profit in 10 days with tennis signals. Simply incredible! 🎾✨",
      rating: 5,
      sport: "Tennis"
    },
    {
      name: "Ahmed K.",
      location: "Indonesia",
      profit: "$950",
      period: "3 weeks",
      text: "Life-changing service! Made $950 in 3 weeks. The AI analysis is phenomenal. Already recommended to all my friends! 🚀💎",
      rating: 5,
      sport: "Football"
    }
  ];

  // Auto-advance testimonials
  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, testimonials.length]);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    setIsAutoPlaying(false);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    setIsAutoPlaying(false);
  };

  const goToTestimonial = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-yellow-100 px-4 py-2 rounded-full mb-4">
            <Star className="w-5 h-5 text-yellow-600 fill-current" />
            <span className="text-yellow-800 font-semibold">Success Stories</span>
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            What Our Members Say
          </h2>
          <p className="text-xl text-gray-600">
            Real people, real profits, real results 📈
          </p>
        </div>

        {/* Mobile-optimized testimonial carousel */}
        <div className="relative max-w-4xl mx-auto">
          <div className="overflow-hidden rounded-2xl">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0 px-4">
                  <div className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 border border-gray-100 shadow-lg">
                    {/* Rating */}
                    <div className="flex justify-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                      ))}
                    </div>

                    {/* Testimonial text */}
                    <blockquote className="text-lg text-gray-700 text-center mb-6 leading-relaxed">
                      "{testimonial.text}"
                    </blockquote>

                    {/* Profit highlight */}
                    <div className="bg-green-100 rounded-lg p-4 mb-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {testimonial.profit}
                        </div>
                        <div className="text-sm text-green-700">
                          Profit in {testimonial.period} • {testimonial.sport}
                        </div>
                      </div>
                    </div>

                    {/* User info */}
                    <div className="flex items-center justify-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                        <User className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">{testimonial.name}</div>
                        <div className="text-sm text-gray-600">{testimonial.location}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation arrows */}
          <button
            onClick={prevTestimonial}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors md:flex hidden"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          
          <button
            onClick={nextTestimonial}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors md:flex hidden"
          >
            <ChevronRight className="w-6 h-6 text-gray-600" />
          </button>

          {/* Dots indicator */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => goToTestimonial(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-green-500' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          {/* Mobile swipe indicators */}
          <div className="md:hidden mt-6 text-center">
            <p className="text-sm text-gray-500">
              Swipe left or right to see more stories
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Join thousands of successful bettors already profiting with BetSignal
          </p>
          <button className="bg-gradient-to-r from-green-500 to-blue-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:from-green-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-200 shadow-lg">
            Start Your Success Story! 🌟
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;