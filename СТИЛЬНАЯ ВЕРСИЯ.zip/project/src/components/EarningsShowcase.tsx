import React, { useEffect, useState } from 'react';
import { DollarSign, TrendingUp, Calendar, BarChart3, Target, Zap } from 'lucide-react';

const EarningsShowcase = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [earnings, setEarnings] = useState(0);
  const [currentDay, setCurrentDay] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          
          // Animate earnings counter
          let start = 0;
          const target = 1850;
          const duration = 2500;
          const increment = target / (duration / 16);
          
          const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
              setEarnings(target);
              clearInterval(timer);
            } else {
              setEarnings(Math.floor(start));
            }
          }, 16);

          return () => clearInterval(timer);
        }
      },
      { threshold: 0.3 }
    );

    const section = document.getElementById('earnings-section');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  // Cycle through days
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDay((prev) => (prev + 1) % chartData.length);
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);

  const chartData = [
    { day: 'Monday', profit: 520, sport: 'Tennis', matches: 8, icon: '🎾' },
    { day: 'Tuesday', profit: 680, sport: 'Football', matches: 6, icon: '⚽' },
    { day: 'Wednesday', profit: 650, sport: 'Basketball', matches: 7, icon: '🏀' },
  ];

  return (
    <section id="earnings-section" className="py-20 bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-green-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-purple-200/30 to-pink-200/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className={`transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          {/* Enhanced Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-green-100 to-emerald-100 px-6 py-3 rounded-full mb-6 border border-green-200">
              <DollarSign className="w-6 h-6 text-green-600" />
              <span className="text-green-800 font-bold text-lg">Live Performance Data</span>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 leading-tight">
              Our Signals Earned{' '}
              <span className="bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                ${earnings.toLocaleString()}
              </span>
            </h2>
            <p className="text-2xl text-gray-600 font-semibold">
              in the Last 3 Days! 
              <span className="inline-block ml-2 animate-bounce">📈</span>
            </p>
          </div>

          {/* Main Dashboard */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 md:p-12 max-w-6xl mx-auto border border-gray-100">
            {/* Stats Overview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
              <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl border border-green-200">
                <Target className="w-8 h-8 text-green-600 mx-auto mb-3" />
                <div className="text-2xl font-black text-gray-900">21</div>
                <div className="text-sm text-gray-600 font-semibold">Total Signals</div>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl border border-blue-200">
                <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <div className="text-2xl font-black text-gray-900">18</div>
                <div className="text-sm text-gray-600 font-semibold">Wins</div>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border border-purple-200">
                <BarChart3 className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                <div className="text-2xl font-black text-gray-900">86%</div>
                <div className="text-sm text-gray-600 font-semibold">Win Rate</div>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-2xl border border-yellow-200">
                <Zap className="w-8 h-8 text-yellow-600 mx-auto mb-3" />
                <div className="text-2xl font-black text-gray-900">$617</div>
                <div className="text-sm text-gray-600 font-semibold">Avg/Day</div>
              </div>
            </div>

            {/* Daily Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {chartData.map((data, index) => {
                const isActive = index === currentDay;
                
                return (
                  <div 
                    key={index} 
                    className={`p-6 rounded-2xl border transition-all duration-500 transform ${
                      isActive 
                        ? 'bg-gradient-to-br from-green-100 to-blue-100 border-green-300 scale-105 shadow-xl' 
                        : 'bg-gray-50 border-gray-200 hover:scale-102 hover:shadow-lg'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <Calendar className={`w-6 h-6 ${isActive ? 'text-blue-600' : 'text-gray-500'}`} />
                        <span className="font-bold text-gray-900">{data.day}</span>
                      </div>
                      <span className="text-2xl">{data.icon}</span>
                    </div>
                    
                    <div className={`text-3xl font-black mb-2 ${isActive ? 'text-green-600' : 'text-gray-900'}`}>
                      +${data.profit}
                    </div>
                    
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>{data.sport} • {data.matches} matches</div>
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                        <span>Live tracking</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Visual Chart */}
            <div className="relative mb-8">
              <div className="flex items-end justify-center gap-8 h-32 mb-6">
                {chartData.map((data, index) => (
                  <div key={index} className="flex flex-col items-center group">
                    <div 
                      className={`bg-gradient-to-t from-green-500 to-blue-500 rounded-t-lg transition-all duration-1000 w-16 md:w-20 group-hover:from-green-600 group-hover:to-blue-600 ${
                        index === currentDay ? 'shadow-lg ring-2 ring-blue-300' : ''
                      }`}
                      style={{
                        height: isVisible ? `${(data.profit / 680) * 100}px` : '0px'
                      }}
                    />
                    <span className="text-sm text-gray-600 mt-3 font-semibold">{data.day.slice(0, 3)}</span>
                  </div>
                ))}
              </div>
              
              <div className="flex items-center justify-center gap-3 text-gray-600">
                <TrendingUp className="w-5 h-5 text-green-500" />
                <span className="font-semibold">Consistent daily profits with verified AI signals</span>
              </div>
            </div>

            {/* CTA Section */}
            <div className="text-center bg-gradient-to-r from-green-50 to-blue-50 p-8 rounded-2xl border border-green-200">
              <p className="text-gray-700 mb-6 text-lg leading-relaxed">
                These are <span className="font-bold text-green-600">real, verified results</span> from our community. 
                Your results may vary, but our track record speaks for itself.
              </p>
              
              <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
                <button className="group bg-gradient-to-r from-green-500 to-blue-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:from-green-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-300 shadow-xl w-full md:w-auto">
                  <span className="flex items-center justify-center gap-2">
                    Start Earning Today! 
                    <DollarSign className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                  </span>
                </button>
                
                <div className="text-center">
                  <p className="text-sm text-gray-600">Join 10,000+ profitable members</p>
                  <p className="text-xs text-gray-500">3-day free trial • No commitment</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EarningsShowcase;