import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

const StickyButton = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const handleJoinNow = () => {
    // Scroll to free trial form
    const freeTrialSection = document.getElementById('earnings-section');
    if (freeTrialSection) {
      freeTrialSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Sticky CTA Button */}
      <div className="fixed bottom-4 left-4 right-4 z-50 md:hidden">
        <button
          onClick={handleJoinNow}
          className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white py-4 px-6 rounded-lg text-lg font-bold shadow-2xl hover:from-green-600 hover:to-blue-600 transform hover:scale-105 transition-all duration-200 animate-pulse"
        >
          Join for $99 - Start Winning! 🚀
        </button>
      </div>

      {/* Scroll to top button */}
      {isVisible && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-24 right-4 z-40 w-12 h-12 bg-gray-900 text-white rounded-full shadow-lg hover:bg-gray-800 transition-all duration-200 flex items-center justify-center md:bottom-4"
        >
          <ArrowUp className="w-6 h-6" />
        </button>
      )}
    </>
  );
};

export default StickyButton;