import React, { useState } from 'react';
import WelcomeScreen from './components/WelcomeScreen';
import Header from './components/Header';
import Hero from './components/Hero';
import SuccessRate from './components/SuccessRate';
import EarningsShowcase from './components/EarningsShowcase';
import FreeTrialForm from './components/FreeTrialForm';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';
import StickyButton from './components/StickyButton';

function App() {
  const [showWelcome, setShowWelcome] = useState(true);

  const handleWelcomeComplete = () => {
    setShowWelcome(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Welcome Screen */}
      {showWelcome && <WelcomeScreen onComplete={handleWelcomeComplete} />}
      
      {/* Main Website Content */}
      {!showWelcome && (
        <>
          {/* Header with enhanced navigation */}
          <Header />
          
          {/* Hero section with dynamic stats and enhanced animations */}
          <Hero />
          
          {/* Success rate section with animated metrics */}
          <SuccessRate />
          
          {/* Enhanced earnings showcase with live data visualization */}
          <EarningsShowcase />
          
          {/* Free trial form with improved countdown and UX */}
          <FreeTrialForm />
          
          {/* Enhanced testimonials carousel */}
          <Testimonials />
          
          {/* Footer with comprehensive legal disclaimers */}
          <Footer />
          
          {/* Sticky mobile CTA button */}
          <StickyButton />
        </>
      )}
    </div>
  );
}

export default App;